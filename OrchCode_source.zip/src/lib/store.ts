import { create } from "zustand";
import { immer } from "zustand/middleware/immer";
import { listen } from "@tauri-apps/api/event";
import * as api from "./api";
import { newId } from "./api";
import { useWorkspaceStore, registerWorkspaceActivatedCallback } from "./workspace";
import { useArtifactsStore } from "./artifacts";
import type {
  AttachmentRef,
  Budget,
  ChatStreamEvent,
  MessageItemView,
  ModelDto,
  SessionSummary,
  ToolDisplayInfo,
} from "./api";

export interface MessageAttachment {
  name: string;
  isImage: boolean;
  path?: string;
  dataUrl?: string;
}

export interface ReasoningItem {
  type: "reasoning";
  id: string;
  text: string;
  active: boolean;
  startTime: number;
  durationSeconds?: number;
}

export interface ToolCallItem {
  type: "toolCall";
  id: string;
  name: string;
  args: string;
  displayInfo: ToolDisplayInfo;
  output?: string;
  status: "running" | "done" | "error";
}

export interface TextItem {
  type: "text";
  id: string;
  text: string;
}

export interface CompactionNoticeItem {
  type: "compactionNotice";
  id: string;
  originalMessageCount: number;
  ts: number;
}

export type MessageItem = ReasoningItem | ToolCallItem | TextItem | CompactionNoticeItem;

export interface TokenUsage {
  contextTokens: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  items: MessageItem[];
  attachments: MessageAttachment[];
  streaming: boolean;
  error?: string;
  notice?: string;
}

const ZERO_USAGE: TokenUsage = { contextTokens: 0 };

function viewItemToLocal(item: MessageItemView): MessageItem {
  switch (item.type) {
    case "text":
      return { type: "text", id: item.id, text: item.text };
    case "reasoning":
      return {
        type: "reasoning",
        id: item.id,
        text: item.text,
        active: false,
        startTime: 0,
        durationSeconds: item.durationSeconds ?? undefined,
      };
    case "compactionNotice":
      return {
        type: "compactionNotice",
        id: item.id,
        originalMessageCount: item.originalMessageCount,
        ts: item.ts,
      };
    case "toolCall":
      return {
        type: "toolCall",
        id: item.id,
        name: item.name,
        args: item.args,
        displayInfo: item.displayInfo,
        output: item.output ?? undefined,
        status: item.status === "error" ? "error" : "done",
      };
  }
}

function usageFrom(session: SessionSummary): TokenUsage {
  return {
    contextTokens: session.contextTokens,
  };
}

interface ChatState {
  sessions: SessionSummary[];
  currentSessionId: string;
  messages: ChatMessage[];
  streaming: boolean;
  streamingSessionId: string | null;
  sessionTokens: TokenUsage;
  models: ModelDto[];
  selectedModel: ModelDto | null;
  budget: Budget | null;
  error: string | null;
  initialized: boolean;
}

interface ChatActions {
  initialize: () => Promise<void>;
  reloadForWorkspace: () => Promise<void>;
  reset: () => void;
  newChat: () => void;
  selectSession: (id: string) => Promise<void>;
  deleteSession: (id: string) => Promise<void>;
  send: (prompt: string, attachments: AttachmentRef[]) => Promise<boolean>;
  cancel: () => void;
  setSelectedModel: (key: string) => void;
  refreshSessions: () => Promise<void>;
  refreshModels: () => Promise<void>;
  refreshBudget: () => Promise<void>;
  dismissError: () => void;
}

export type ChatStore = ChatState & ChatActions;

const INITIAL_STATE: ChatState = {
  sessions: [],
  currentSessionId: newId(),
  messages: [],
  streaming: false,
  streamingSessionId: null,
  sessionTokens: ZERO_USAGE,
  models: [],
  selectedModel: null,
  budget: null,
  error: null,
  initialized: false,
};

type UnlistenFn = () => void;
let boundUnlisteners: UnlistenFn[] = [];
let listenerEpoch = 0;
let initEpoch = 0;

function unbindListeners() {
  listenerEpoch += 1;
  for (const fn of boundUnlisteners) fn();
  boundUnlisteners = [];
}

async function bindListeners() {
  unbindListeners();
  const epoch = listenerEpoch;
  const fns = await Promise.all([
    listen("sessions-updated", () => {
      void useChatStore.getState().refreshSessions();
    }),
    listen("models-updated", () => {
      void useChatStore.getState().refreshModels();
    }),
  ]);
  if (epoch !== listenerEpoch) {
    for (const fn of fns) fn();
    return;
  }
  boundUnlisteners = fns;
}

function pickModel(models: ModelDto[], key: string | null | undefined): ModelDto | null {
  return (key ? models.find((m) => m.key === key) : undefined) ?? models[0] ?? null;
}


export const useChatStore = create(
  immer<ChatStore>((set, get) => ({
    ...INITIAL_STATE,

    initialize: async () => {
      if (get().initialized) return;
      set((s) => { s.initialized = true; });
      const epoch = initEpoch;

      const wsPath = useWorkspaceStore.getState().current?.path ?? null;

      const [sessions, models, savedModel] = await Promise.all([
        wsPath
          ? api.listSessionsForWorkspace(wsPath).catch(() => [] as SessionSummary[])
          : Promise.resolve([] as SessionSummary[]),
        api.listModels().catch(() => [] as ModelDto[]),
        api.getUserPref("selectedModel").catch(() => null),
      ]);
      if (epoch !== initEpoch) return;

      set((s) => {
        s.sessions = sessions;
        s.models = models;
        s.selectedModel = pickModel(models, savedModel);
      });

      void get().refreshBudget();
      await bindListeners();
    },

    reloadForWorkspace: async () => {
      const running = get().streamingSessionId;
      if (running) await api.cancelChat(running).catch(() => undefined);
      const wsPath = useWorkspaceStore.getState().current?.path ?? null;
      const freshId = newId();
      useArtifactsStore.getState().dropWorkspaceTabs();

      const sessions = wsPath
        ? await api.listSessionsForWorkspace(wsPath).catch(() => [] as SessionSummary[])
        : [];

      set((s) => {
        s.sessions = sessions;
        s.currentSessionId = freshId;
        s.messages = [];
        s.sessionTokens = ZERO_USAGE;
        s.streaming = false;
        s.streamingSessionId = null;
        s.error = null;
      });
    },

    reset: () => {
      const running = get().streamingSessionId;
      if (running) void api.cancelChat(running).catch(() => undefined);
      initEpoch += 1;
      unbindListeners();
      set((s) => {
        Object.assign(s, INITIAL_STATE, { currentSessionId: newId() });
      });
    },

    newChat: () => {
      if (get().streaming) return;
      const freshId = newId();
      set((s) => {
        s.currentSessionId = freshId;
        s.messages = [];
        s.sessionTokens = ZERO_USAGE;
        s.error = null;
      });
    },

    selectSession: async (id: string) => {
      if (get().streaming || get().currentSessionId === id) return;
      const target = get().sessions.find((s) => s.id === id);

      set((s) => {
        s.currentSessionId = id;
        s.messages = [];
        s.sessionTokens = target ? usageFrom(target) : ZERO_USAGE;
        s.error = null;
      });

      try {
        const views = await api.getSessionView(id);
        set((s) => {
          if (s.currentSessionId !== id) return;
          s.messages = views.map((v) => ({
            id: v.id,
            role: v.role as ChatMessage["role"],
            items: v.items.map(viewItemToLocal),
            attachments: v.attachments.map((a) => ({
              name: a.name,
              isImage: a.isImage,
              dataUrl: a.dataUrl ?? undefined,
            })),
            streaming: false,
          }));
        });
      } catch (e) {
        set((s) => {
          if (s.currentSessionId === id) s.error = api.errorMessage(e);
        });
      }
    },

    deleteSession: async (id: string) => {
      if (get().streaming && (get().streamingSessionId === id || get().currentSessionId === id)) {
        try {
          await api.cancelChat(id);
        } catch {}
      }
      try {
        await api.clearSession(id);
      } catch (e) {
        set((s) => { s.error = api.errorMessage(e); });
        return;
      }
      set((s) => {
        s.sessions = s.sessions.filter((sess) => sess.id !== id);
        if (s.currentSessionId === id) {
          s.currentSessionId = newId();
          s.messages = [];
          s.sessionTokens = ZERO_USAGE;
          s.streaming = false;
          if (s.streamingSessionId === id) s.streamingSessionId = null;
          s.error = null;
        }
      });
    },

    send: async (prompt: string, attachments: AttachmentRef[]) => {
      const { streaming, currentSessionId, selectedModel } = get();
      const text = prompt.trim();
      if (streaming) return false;
      if (!text && attachments.length === 0) return false;
      if (!selectedModel) {
        set((s) => { s.error = "Select a model before sending a message"; });
        return false;
      }

      const sessionId = currentSessionId;
      const userMsgId = newId();
      const assistantMsgId = newId();

      set((s) => {
        s.error = null;
        s.streaming = true;
        s.streamingSessionId = sessionId;
        s.messages.push({
          id: userMsgId,
          role: "user",
          items: [{ type: "text", id: newId(), text }],
          attachments: attachments.map((a) => ({
            name: a.name,
            isImage: a.isImage,
            path: a.path,
          })),
          streaming: false,
        });
        s.messages.push({
          id: assistantMsgId,
          role: "assistant",
          items: [],
          attachments: [],
          streaming: true,
        });
      });

      const patch = (fn: (m: ChatMessage) => void) => {
        set((s) => {
          if (s.currentSessionId !== sessionId) return;
          const msg = s.messages.find((m) => m.id === assistantMsgId);
          if (msg) fn(msg);
        });
      };

      let settled = false;
      const settle = () => {
        if (settled) return;
        settled = true;
        patch((m) => { m.streaming = false; });
        set((s) => {
          if (s.streamingSessionId === sessionId) s.streamingSessionId = null;
          if (s.currentSessionId === sessionId) s.streaming = false;
        });
      };

      let receivedEvents = false;

      let textBuffer = "";
      let reasoningBuffer = "";
      let rafId: number | null = null;

      const flush = () => {
        const pendingText = textBuffer;
        const pendingReasoning = reasoningBuffer;
        textBuffer = "";
        reasoningBuffer = "";
        if (!pendingText && !pendingReasoning) return;
        patch((m) => {
          if (pendingReasoning) {
            const last = m.items[m.items.length - 1];
            if (last?.type === "reasoning" && last.active) last.text += pendingReasoning;
            else m.items.push({ type: "reasoning", id: newId(), text: pendingReasoning, active: true, startTime: Date.now() });
          }
          if (pendingText) {
            const last = m.items[m.items.length - 1];
            if (last?.type === "text") last.text += pendingText;
            else m.items.push({ type: "text", id: newId(), text: pendingText });
          }
        });
      };

      const scheduleFlush = () => {
        if (rafId === null) {
          rafId = requestAnimationFrame(() => {
            rafId = null;
            flush();
          });
          setTimeout(() => {
            if (rafId !== null) {
              cancelAnimationFrame(rafId);
              rafId = null;
              flush();
            }
          }, 100);
        }
      };

      const syncFlush = () => {
        if (rafId !== null) {
          cancelAnimationFrame(rafId);
          rafId = null;
        }
        flush();
      };

      const handleEvent = (event: ChatStreamEvent) => {
        receivedEvents = true;
        switch (event.type) {
          case "text":
            textBuffer += event.delta;
            scheduleFlush();
            break;
          case "reasoning":
            reasoningBuffer += event.delta;
            scheduleFlush();
            break;
          case "reasoningDone":
            syncFlush();
            patch((m) => {
              for (let i = m.items.length - 1; i >= 0; i--) {
                const item = m.items[i];
                if (item.type === "reasoning" && item.active) {
                  item.active = false;
                  item.durationSeconds = event.durationSeconds;
                  break;
                }
              }
            });
            break;
          case "toolCall":
            syncFlush();
            patch((m) => {
              m.items.push({ type: "toolCall", id: event.id, name: event.name, args: event.args, displayInfo: event.displayInfo, status: "running" });
            });
            break;
          case "toolResult":
            patch((m) => {
              const item = m.items.find((i): i is ToolCallItem => i.type === "toolCall" && i.id === event.id);
              if (item) { item.output = event.output; item.status = event.isError ? "error" : "done"; }
            });
            break;
          case "usage":
            set((s) => {
              if (s.currentSessionId === sessionId)
                s.sessionTokens = { contextTokens: event.contextTokens };
            });
            break;
          case "notice":
            patch((m) => { m.notice = event.message; });
            break;
          case "compacted": {
            set((s) => {
              if (s.currentSessionId !== sessionId) return;
              const notice: ChatMessage = {
                id: newId(),
                role: "system",
                items: [{ type: "compactionNotice", id: newId(), originalMessageCount: event.originalMessageCount, ts: event.ts }],
                attachments: [],
                streaming: false,
              };
              const streamingIdx = s.messages.findIndex((m) => m.id === assistantMsgId);
              if (streamingIdx >= 0) {
                s.messages.splice(streamingIdx, 0, notice);
              } else {
                s.messages.push(notice);
              }
            });
            break;
          }
          case "done":
            syncFlush(); settle();
            void useChatStore.getState().refreshBudget();
            break;
          case "cancelled":
            syncFlush(); settle();
            break;
          case "error":
            syncFlush();
            patch((m) => { m.error = event.message; });
            settle();
            break;
        }
      };

      try {
        await api.startChat(sessionId, selectedModel.key, text, attachments, handleEvent);
        syncFlush(); settle();
        return true;
      } catch (e) {
        const message = api.errorMessage(e);
        syncFlush(); settle();
        if (!receivedEvents) {
          set((s) => {
            s.messages = s.messages.filter((m) => m.id !== userMsgId && m.id !== assistantMsgId);
            if (s.currentSessionId === sessionId && message !== "cancelled") s.error = message;
          });
          return false;
        }
        patch((m) => { m.error = message; });
        set((s) => {
          if (s.currentSessionId === sessionId) s.error = message;
        });
        return true;
      }
    },

    cancel: () => {
      const target = get().streamingSessionId ?? get().currentSessionId;
      void api.cancelChat(target).catch(() => undefined);
    },

    setSelectedModel: (key: string) => {
      const model = get().models.find((m) => m.key === key);
      if (!model) return;
      set((s) => { s.selectedModel = model; });
      void api.setUserPref("selectedModel", key).catch(() => undefined);
    },

    refreshSessions: async () => {
      try {
        const wsPath = useWorkspaceStore.getState().current?.path ?? null;
        if (!wsPath) return;
        const sessions = await api.listSessionsForWorkspace(wsPath);
        if (useWorkspaceStore.getState().current?.path !== wsPath) return;
        set((s) => {
          s.sessions = sessions;
          if (!s.streaming) {
            const current = sessions.find((sess) => sess.id === s.currentSessionId);
            if (current) s.sessionTokens = usageFrom(current);
          }
        });
      } catch {
        return;
      }
    },

    refreshModels: async () => {
      try {
        const models = await api.listModels();
        set((s) => {
          s.models = models;
          s.selectedModel = pickModel(models, s.selectedModel?.key);
        });
      } catch {
        return;
      }
    },

    refreshBudget: async () => {
      try {
        const budget = await api.getBudget();
        set((s) => { s.budget = budget; });
      } catch {
        return;
      }
    },

    dismissError: () => {
      set((s) => { s.error = null; });
    },
  }))
);

registerWorkspaceActivatedCallback(() => {
  if (useChatStore.getState().initialized) void useChatStore.getState().reloadForWorkspace();
});
