use std::collections::HashMap;
use std::io::{Cursor, Read};
use std::path::Path;

use sha2::{Digest, Sha256};
use uuid::Uuid;
use zip::ZipArchive;

use text_splitter::{ChunkConfig, TextSplitter};

use crate::error::{AppError, AppResult};
use crate::persistence::{DocumentRecord, PassageRecord, SqliteMemory};
use crate::util::now_ms;

const PASSAGE_CHARS: usize = 2048;
const PASSAGE_OVERLAP: usize = 200;

#[derive(Debug, Clone)]
pub struct IngestResult {
    pub document_id: String,
    pub title: String,
    pub file_type: String,
    pub passage_count: usize,
    pub word_count: usize,
    pub page_count: Option<usize>,
    pub was_update: bool,
}

async fn persist_document(
    doc: DocumentRecord,
    text: &str,
    page_boundaries: Vec<(usize, usize)>,
    memory: &SqliteMemory,
) -> AppResult<usize> {
    let doc_id = doc.id.clone();
    let text_clone = text.to_string();
    let passages = tokio::task::spawn_blocking(move || {
        chunk_text_into_passages(&text_clone, &doc_id, page_boundaries)
    })
    .await
    .map_err(|e| AppError::DocumentParseError(format!("chunking task failed: {e}")))?;
    let count = passages.len();
    memory.replace_document_with_passages(doc, passages).await?;
    Ok(count)
}

pub const MAX_INGEST_FILE_BYTES: u64 = 50 * 1024 * 1024;
pub const MAX_DECOMPRESSED_ENTRY_BYTES: u64 = 25 * 1024 * 1024;

pub async fn ingest_document(path: &Path, memory: &SqliteMemory) -> AppResult<IngestResult> {
    let canonical = dunce::canonicalize(path)
        .map_err(|e| AppError::DocumentParseError(format!("cannot resolve path: {e}")))?;
    let metadata = std::fs::metadata(&canonical).map_err(AppError::Io)?;
    if !metadata.is_file() {
        return Err(AppError::DocumentParseError(format!(
            "not a file: {}",
            canonical.display()
        )));
    }
    if metadata.len() > MAX_INGEST_FILE_BYTES {
        return Err(AppError::FileTooLarge(format!(
            "file too large to ingest ({} MB, limit {} MB): {}",
            metadata.len() / (1024 * 1024),
            MAX_INGEST_FILE_BYTES / (1024 * 1024),
            canonical.display()
        )));
    }

    let canonical_path = canonical.to_string_lossy().into_owned();
    let file_type = detect_file_type(&canonical)?;
    let existing_id = memory.document_exists_by_path(&canonical_path).await?;
    let was_update = existing_id.is_some();
    let doc_id = existing_id.unwrap_or_else(|| Uuid::new_v4().to_string());
    let size_bytes = metadata.len() as i64;

    let canonical_clone = canonical.clone();
    let file_type_clone = file_type.clone();
    let parsed = tokio::task::spawn_blocking(move || parse_document(&canonical_clone, &file_type_clone))
        .await
        .map_err(|e| AppError::DocumentParseError(format!("task failed: {e}")))??;

    let word_count = count_words(&parsed.full_text);
    let title = parsed.title.unwrap_or_else(|| file_stem_title(&canonical));
    let now = now_ms();

    let doc = DocumentRecord {
        id: doc_id.clone(),
        title: title.clone(),
        file_path: Some(canonical_path.clone()),
        source: "local".to_string(),
        source_id: None,
        file_type: file_type.clone(),
        size_bytes,
        page_count: parsed.page_count.map(|p| p as i64),
        word_count: Some(word_count as i64),
        metadata: serde_json::json!({ "path": canonical_path }),
        indexed_at: now,
        updated_at: now,
    };

    let passage_count = persist_document(doc, &parsed.full_text, parsed.page_boundaries, memory).await?;

    Ok(IngestResult {
        document_id: doc_id,
        title,
        file_type,
        passage_count,
        word_count,
        page_count: parsed.page_count,
        was_update,
    })
}

pub const SUPPORTED_DOCUMENT_EXTENSIONS: &[&str] = &["pdf", "docx", "xlsx", "xls", "ods", "pptx"];

pub fn is_supported_document_extension(ext: &str) -> bool {
    SUPPORTED_DOCUMENT_EXTENSIONS.contains(&ext)
}

fn detect_file_type(path: &Path) -> AppResult<String> {
    let ext = path
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_lowercase())
        .unwrap_or_default();

    if is_supported_document_extension(&ext) {
        let canonical = match ext.as_str() {
            "xls" | "ods" => "xlsx",
            other => other,
        };
        return Ok(canonical.to_string());
    }

    match ext.as_str() {
        "txt" | "text" | "md" | "markdown" | "csv" | "json" | "html" | "htm" | "xml" | "rtf" => {
            Ok(ext)
        }
        _ => Err(AppError::UnsupportedFileType(format!(
            "'.{ext}' files are not supported. Supported: pdf, docx, xlsx, pptx, txt, md, csv, json, html"
        ))),
    }
}

struct ParsedDocument {
    full_text: String,
    title: Option<String>,
    page_count: Option<usize>,
    page_boundaries: Vec<(usize, usize)>,
}

fn parse_document(path: &Path, file_type: &str) -> AppResult<ParsedDocument> {
    match file_type {
        "pdf" => parse_pdf(path),
        "docx" => parse_office_zip(path, OfficeXmlKind::Word),
        "xlsx" => parse_xlsx(path),
        "pptx" => parse_office_zip(path, OfficeXmlKind::Pptx),
        _ => parse_plain_text(path),
    }
}

fn parse_pdf(path: &Path) -> AppResult<ParsedDocument> {
    let doc = lopdf::Document::load(path)
        .map_err(|e| AppError::DocumentParseError(format!("PDF load failed: {e}")))?;

    let pages = doc.get_pages();
    let page_count = pages.len();
    let mut full_text = String::new();
    let mut page_boundaries = Vec::new();

    for (page_num, _page_id) in &pages {
        if let Ok(text) = doc.extract_text(&[*page_num]) {
            let cleaned = clean_pdf_text(&text);
            if !cleaned.trim().is_empty() {
                let page_offset = full_text.len();
                page_boundaries.push((page_offset, *page_num as usize));
                full_text.push_str(&cleaned);
                full_text.push('\n');
            }
        }
    }

    Ok(ParsedDocument { full_text, title: None, page_count: Some(page_count), page_boundaries })
}

fn clean_pdf_text(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    for line in text.lines() {
        let mut first_word = true;
        for word in line.split_whitespace() {
            let filtered: String = word
                .chars()
                .filter(|c| !c.is_control() || *c == '\t')
                .collect();
            if !filtered.is_empty() {
                if !first_word {
                    out.push(' ');
                } else if !out.is_empty() {
                    out.push('\n');
                }
                out.push_str(&filtered);
                first_word = false;
            }
        }
    }
    out
}

enum OfficeXmlKind {
    Word,
    Pptx,
}

fn parse_office_zip(path: &Path, kind: OfficeXmlKind) -> AppResult<ParsedDocument> {
    let data = std::fs::read(path).map_err(AppError::Io)?;
    let cursor = Cursor::new(data);
    let mut zip = ZipArchive::new(cursor)
        .map_err(|e| AppError::DocumentParseError(format!("ZIP open error: {e}")))?;

    let title = read_zip_entry(&mut zip, "docProps/core.xml")
        .ok()
        .and_then(|xml| extract_xml_element(&xml, "dc:title").ok())
        .filter(|t| !t.is_empty());

    match kind {
        OfficeXmlKind::Word => {
            let xml_text = read_zip_entry(&mut zip, "word/document.xml")?;
            let text = extract_office_text(&xml_text)?;
            Ok(ParsedDocument { full_text: text, title, page_count: None, page_boundaries: vec![] })
        }
        OfficeXmlKind::Pptx => {
            let sorted_slides = ordered_pptx_slides(&mut zip);
            let slide_count = sorted_slides.len();
            let mut full_text = String::new();
            let mut page_boundaries = Vec::new();

            for (idx, slide_name) in sorted_slides.iter().enumerate() {
                let slide_num = idx + 1;
                let offset = full_text.len();
                page_boundaries.push((offset, slide_num));
                let xml = read_zip_entry(&mut zip, slide_name)?;
                let slide_text = extract_office_text(&xml)?;
                if !slide_text.trim().is_empty() {
                    full_text.push_str(&format!("=== Slide {slide_num} ===\n{slide_text}\n\n"));
                }
            }

            Ok(ParsedDocument {
                full_text,
                title,
                page_count: Some(slide_count),
                page_boundaries,
            })
        }
    }
}

fn ordered_pptx_slides(zip: &mut ZipArchive<Cursor<Vec<u8>>>) -> Vec<String> {
    if let (Ok(pres_xml), Ok(rels_xml)) = (
        read_zip_entry(zip, "ppt/presentation.xml"),
        read_zip_entry(zip, "ppt/_rels/presentation.xml.rels"),
    ) {
        let mut rid_to_target: HashMap<String, String> = HashMap::new();
        use quick_xml::events::Event;
        use quick_xml::Reader;

        let mut rels_reader = Reader::from_str(&rels_xml);
        let mut buf = Vec::new();
        while let Ok(event) = rels_reader.read_event_into(&mut buf) {
            match event {
                Event::Start(ref e) | Event::Empty(ref e) if e.local_name().as_ref() == b"Relationship" => {
                    let mut id = None;
                    let mut target = None;
                    for attr in e.attributes().flatten() {
                        if attr.key.as_ref() == b"Id" {
                            id = String::from_utf8(attr.value.to_vec()).ok();
                        } else if attr.key.as_ref() == b"Target" {
                            target = String::from_utf8(attr.value.to_vec()).ok();
                        }
                    }
                    if let (Some(id), Some(target)) = (id, target) {
                        let normalized_target = if target.starts_with('/') {
                            target.trim_start_matches('/').to_string()
                        } else if target.starts_with("ppt/") {
                            target
                        } else {
                            format!("ppt/{target}")
                        };
                        rid_to_target.insert(id, normalized_target);
                    }
                }
                Event::Eof => break,
                _ => {}
            }
            buf.clear();
        }

        let mut ordered = Vec::new();
        let mut pres_reader = Reader::from_str(&pres_xml);
        while let Ok(event) = pres_reader.read_event_into(&mut buf) {
            match event {
                Event::Start(ref e) | Event::Empty(ref e) if e.local_name().as_ref() == b"sldId" => {
                    for attr in e.attributes().flatten() {
                        if attr.key.local_name().as_ref() == b"id" && attr.key.as_ref().starts_with(b"r:") {
                            if let Ok(rid) = String::from_utf8(attr.value.to_vec()) {
                                if let Some(target) = rid_to_target.get(&rid) {
                                    ordered.push(target.clone());
                                }
                            }
                        }
                    }
                }
                Event::Eof => break,
                _ => {}
            }
            buf.clear();
        }

        if !ordered.is_empty() {
            return ordered;
        }
    }

    let mut slide_names: Vec<String> = (0..zip.len())
        .filter_map(|i| {
            let entry = zip.by_index(i).ok()?;
            let raw_name = entry.name().replace('\\', "/");
            if raw_name.starts_with("ppt/slides/slide") && raw_name.ends_with(".xml") {
                Some(entry.name().to_string())
            } else {
                None
            }
        })
        .collect();

    slide_names.sort_by_key(|s| {
        let norm = s.replace('\\', "/");
        norm.strip_prefix("ppt/slides/slide")
            .and_then(|p| p.strip_suffix(".xml"))
            .and_then(|n| n.parse::<usize>().ok())
            .unwrap_or(0)
    });

    slide_names
}

fn read_zip_entry(zip: &mut ZipArchive<Cursor<Vec<u8>>>, name: &str) -> AppResult<String> {
    let mut entry = zip
        .by_name(name)
        .map_err(|e| AppError::DocumentParseError(format!("zip entry '{name}' not found: {e}")))?;
    let mut content = String::new();
    let read_bytes = entry
        .by_ref()
        .take(MAX_DECOMPRESSED_ENTRY_BYTES + 1)
        .read_to_string(&mut content)
        .map_err(|e| AppError::DocumentParseError(format!("zip read '{name}': {e}")))?;
    if read_bytes as u64 > MAX_DECOMPRESSED_ENTRY_BYTES {
        return Err(AppError::FileTooLarge(format!(
            "zip entry '{name}' exceeds maximum decompressed size limit of {} MB",
            MAX_DECOMPRESSED_ENTRY_BYTES / (1024 * 1024)
        )));
    }
    Ok(content)
}

fn extract_office_text(xml: &str) -> AppResult<String> {
    use quick_xml::events::Event;
    use quick_xml::Reader;

    let mut reader = Reader::from_str(xml);
    reader.config_mut().trim_text(false);

    let mut text = String::new();
    let mut in_text = false;
    let mut skip_depth: usize = 0;
    let mut buf = Vec::new();

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(ref e)) => {
                let local = e.local_name();
                let lb = local.as_ref();
                match lb {
                    b"del" | b"delText" | b"instrText" => skip_depth += 1,
                    b"t" if skip_depth == 0 => in_text = true,
                    b"p" => {
                        if !text.is_empty() && !text.ends_with('\n') {
                            text.push('\n');
                        }
                    }
                    b"tc" => {
                        if !text.is_empty() && !text.ends_with('\t') && !text.ends_with('\n') {
                            text.push('\t');
                        }
                    }
                    _ => {}
                }
            }
            Ok(Event::Empty(ref e)) => {
                let local = e.local_name();
                let lb = local.as_ref();
                if skip_depth == 0 {
                    match lb {
                        b"br" | b"cr" => text.push('\n'),
                        b"tab" => text.push('\t'),
                        _ => {}
                    }
                }
            }
            Ok(Event::End(ref e)) => {
                let local = e.local_name();
                let lb = local.as_ref();
                match lb {
                    b"del" | b"delText" | b"instrText" => {
                        skip_depth = skip_depth.saturating_sub(1);
                    }
                    b"t" => {
                        in_text = false;
                    }
                    _ => {}
                }
            }
            Ok(Event::Text(e)) => {
                if in_text && skip_depth == 0 {
                    if let Ok(t) = e.unescape() {
                        text.push_str(&t);
                    }
                }
            }
            Ok(Event::CData(e)) => {
                if in_text && skip_depth == 0 {
                    if let Ok(t) = std::str::from_utf8(e.as_ref()) {
                        text.push_str(t);
                    }
                }
            }
            Ok(Event::Eof) | Err(_) => break,
            _ => {}
        }
        buf.clear();
    }

    Ok(text)
}

fn extract_xml_element(xml: &str, tag: &str) -> AppResult<String> {
    use quick_xml::events::Event;
    use quick_xml::Reader;

    let mut reader = Reader::from_str(xml);
    let mut in_target = false;
    let mut buf = Vec::new();
    let mut result = String::new();
    let tag_local = tag.split(':').last().unwrap_or(tag).as_bytes();

    loop {
        match reader.read_event_into(&mut buf) {
            Ok(Event::Start(ref e)) => {
                if e.local_name().as_ref() == tag_local {
                    in_target = true;
                }
            }
            Ok(Event::End(ref e)) => {
                if e.local_name().as_ref() == tag_local {
                    in_target = false;
                }
            }
            Ok(Event::Text(e)) if in_target => {
                if let Ok(t) = e.unescape() {
                    result.push_str(&t);
                }
            }
            Ok(Event::CData(e)) if in_target => {
                if let Ok(t) = std::str::from_utf8(e.as_ref()) {
                    result.push_str(t);
                }
            }
            Ok(Event::Eof) | Err(_) => break,
            _ => {}
        }
        buf.clear();
    }

    Ok(result)
}

fn parse_xlsx(path: &Path) -> AppResult<ParsedDocument> {
    use calamine::{open_workbook_auto, Data, Reader};

    let mut workbook = open_workbook_auto(path)
        .map_err(|e| AppError::DocumentParseError(format!("XLSX open failed: {e}")))?;

    let sheet_names = workbook.sheet_names().to_vec();
    let mut full_text = String::new();

    for sheet_name in &sheet_names {
        if let Ok(range) = workbook.worksheet_range(sheet_name) {
            full_text.push_str(&format!("=== Sheet: {sheet_name} ===\n"));
            for row in range.rows() {
                let row_text: Vec<String> = row
                    .iter()
                    .map(|cell| match cell {
                        Data::Empty => String::new(),
                        Data::String(s) => s.clone(),
                        Data::Float(f) => {
                            if *f == f.floor() && f.abs() < 1e15 {
                                format!("{}", *f as i64)
                            } else {
                                format!("{f}")
                            }
                        }
                        Data::Int(i) => i.to_string(),
                        Data::Bool(b) => b.to_string(),
                        Data::DateTime(dt) => format!("{dt}"),
                        Data::DateTimeIso(s) | Data::DurationIso(s) => s.clone(),
                        Data::Error(e) => format!("[err:{e:?}]"),
                    })
                    .filter(|s| !s.is_empty())
                    .collect();
                if !row_text.is_empty() {
                    full_text.push_str(&row_text.join("\t"));
                    full_text.push('\n');
                }
            }
            full_text.push('\n');
        }
    }

    Ok(ParsedDocument {
        full_text,
        title: None,
        page_count: Some(sheet_names.len()),
        page_boundaries: vec![],
    })
}

fn parse_plain_text(path: &Path) -> AppResult<ParsedDocument> {
    let raw = std::fs::read(path).map_err(AppError::Io)?;
    let (cow, _, _) = encoding_rs::UTF_8.decode(&raw);
    Ok(ParsedDocument {
        full_text: cow.into_owned(),
        title: None,
        page_count: None,
        page_boundaries: vec![],
    })
}

fn chunk_text_into_passages(
    text: &str,
    document_id: &str,
    page_boundaries: Vec<(usize, usize)>,
) -> Vec<PassageRecord> {
    if text.trim().is_empty() {
        return vec![];
    }

    let config = ChunkConfig::new(PASSAGE_CHARS)
        .with_overlap(PASSAGE_OVERLAP)
        .unwrap_or_else(|_| ChunkConfig::new(PASSAGE_CHARS));
    let splitter = TextSplitter::new(config);

    let mut passages = Vec::new();
    let mut seq = 0i64;

    for (start, chunk) in splitter.chunk_indices(text) {
        let trimmed = chunk.trim();
        if trimmed.is_empty() {
            continue;
        }
        let end = start + chunk.len();
        let page_number = page_boundaries
            .iter()
            .rev()
            .find(|(offset, _)| *offset <= start)
            .map(|(_, page)| *page as i64);

        passages.push(PassageRecord {
            id: stable_passage_id(document_id, seq),
            document_id: document_id.to_string(),
            seq,
            text: chunk.to_string(),
            page_number,
            char_start: Some(start as i64),
            char_end: Some(end as i64),
        });
        seq += 1;
    }

    passages
}

fn count_words(text: &str) -> usize {
    text.split_whitespace().count()
}

fn file_stem_title(path: &Path) -> String {
    path.file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "Untitled".to_string())
}

fn stable_passage_id(document_id: &str, seq: i64) -> String {
    let input = format!("{document_id}:{seq}");
    let hash = Sha256::digest(input.as_bytes());
    format!(
        "{:016x}",
        u64::from_be_bytes(hash[..8].try_into().unwrap_or([0u8; 8]))
    )
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ParsedDocumentDto {
    pub title: Option<String>,
    pub file_type: String,
    pub page_count: Option<usize>,
    pub full_text: String,
}

pub fn parse_document_file(path: &Path) -> AppResult<ParsedDocumentDto> {
    let canonical = dunce::canonicalize(path)
        .map_err(|e| AppError::DocumentParseError(format!("cannot resolve path: {e}")))?;
    let file_type = detect_file_type(&canonical)?;
    let parsed = parse_document(&canonical, &file_type)?;
    Ok(ParsedDocumentDto {
        title: parsed.title.or_else(|| Some(file_stem_title(&canonical))),
        file_type,
        page_count: parsed.page_count,
        full_text: parsed.full_text,
    })
}

pub fn is_parseable_document(path: &Path) -> bool {
    matches!(
        path.extension()
            .and_then(|e| e.to_str())
            .map(|e| e.to_lowercase())
            .as_deref(),
        Some("pdf" | "docx" | "xlsx" | "xls" | "ods" | "pptx")
    )
}

pub fn parse_document_bytes(bytes: &[u8], extension: &str) -> AppResult<ParsedDocumentDto> {
    let dir = tempfile::tempdir().map_err(AppError::Io)?;
    let file_path = dir.path().join(format!("doc.{}", extension.trim_start_matches('.')));
    std::fs::write(&file_path, bytes).map_err(AppError::Io)?;
    let file_type = detect_file_type(&file_path)?;
    let parsed = parse_document(&file_path, &file_type)?;
    Ok(ParsedDocumentDto {
        title: parsed.title,
        file_type,
        page_count: parsed.page_count,
        full_text: parsed.full_text,
    })
}

#[derive(Debug, Clone, serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SpreadsheetSheet {
    pub name: String,
    pub rows: Vec<Vec<String>>,
    pub total_rows: usize,
    pub truncated: bool,
}

pub fn read_spreadsheet(path: &Path, max_rows: usize, max_cols: usize) -> AppResult<Vec<SpreadsheetSheet>> {
    use calamine::{open_workbook_auto, Data, Reader};

    let mut workbook = open_workbook_auto(path)
        .map_err(|e| AppError::DocumentParseError(format!("spreadsheet open failed: {e}")))?;
    let names = workbook.sheet_names().to_vec();
    let mut sheets = Vec::with_capacity(names.len());
    for name in names {
        let Ok(range) = workbook.worksheet_range(&name) else {
            continue;
        };
        let mut rows = Vec::new();
        let mut total_rows = 0usize;
        for row in range.rows() {
            let cells: Vec<String> = row
                .iter()
                .take(max_cols)
                .map(|cell| match cell {
                    Data::Empty => String::new(),
                    Data::String(s) => s.clone(),
                    Data::Float(f) => {
                        if *f == f.floor() && f.abs() < 1e15 {
                            format!("{}", *f as i64)
                        } else {
                            format!("{f}")
                        }
                    }
                    Data::Int(i) => i.to_string(),
                    Data::Bool(b) => b.to_string(),
                    Data::DateTime(dt) => format!("{dt}"),
                    Data::DateTimeIso(s) | Data::DurationIso(s) => s.clone(),
                    Data::Error(e) => format!("#{e:?}"),
                })
                .collect();
            if cells.iter().all(|c| c.is_empty()) {
                continue;
            }
            total_rows += 1;
            if rows.len() < max_rows {
                rows.push(cells);
            }
        }
        sheets.push(SpreadsheetSheet {
            name,
            truncated: total_rows > rows.len(),
            total_rows,
            rows,
        });
    }
    Ok(sheets)
}
